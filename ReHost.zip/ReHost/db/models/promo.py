import sqlalchemy as sa
from .db_session import SqlAlchemyBase

class Promo(SqlAlchemyBase):
    __tablename__ = 'promo'
    __table_args__ = {'extend_existing': True}

    id = sa.Column(sa.Integer,
                   primary_key=True, autoincrement=True)
    text = sa.Column(sa.String, nullable=True)
    status = sa.Column(sa.Integer, nullable=True)
