import sqlalchemy as sa
from .db_session import SqlAlchemyBase

class User(SqlAlchemyBase):
    __tablename__ = 'users'
    __table_args__ = {'extend_existing': True}

    id = sa.Column(sa.Integer,
                   primary_key=True, autoincrement=True)
    pay_token = sa.Column(sa.String, nullable=True)
    data = sa.Column(sa.String, nullable=True)
    promo = sa.Column(sa.Integer, nullable=True)
