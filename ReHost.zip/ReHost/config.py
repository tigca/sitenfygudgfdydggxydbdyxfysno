"""
Bot configs, texts and container data
"""

BOT = {
    "id": айди админа,
    "token": "токен",
    "parse_mode": "HTML",
    "name": "🌒 Re:Host | Hikka",
    "version": "0.0.1",
    "description": "...",
    "owners": ["Re:Host"],
    "username": "Re:Host",
}

STRING = {
    "start": "👋 <b>{}</b>, приветствую тебя в <b>Re:Host</b>\n\n🚀 Этот бот поможет приобрести хостинг для Hikka юзербота за копейки и очень быстро!",
    "post": "https://teletype.in/@ReHost/tCPXA2hd7D9",
    "keyboard_opened": "⌨ Клавиатура открыта",
    "keyboard": {
        "buy": "💵 Купить хостинг",
        "support": "👨‍💻 Поддержка",
    }, #\nОзнакомьтесь с <a href='https://telegra.ph/none'>инструкцией</a>!",
    "unknown_command": "👀 Неизвестная команда",
    "buy": "<b>📻 Наш тариф включает в себя:</b>\n\n ➖ 350 MB RAM\n ➖ 1 CPU\n ➖ 1 GB Disk\n\n💵 Оплатить хостинг за <b>{} рублей</b> на <b>{}</b>(при наличаи введите промокод):",
    "bill": "💵 Продлить хост за <b>{} рублей</b> на <b>{}</b>:",
    "payed": "💵 Оплата прошла успешно, хост будет создан в течении 5 минут!",
    "not_payed": "💵 Оплата не прошла, попробуйте еще раз...",
    "host_created": "Хостинг создан, теперь вы можете подключить ваш юзербот по адресу:\n<b>{}</b>!",
    "already_have_host": "У вас уже есть хостинг, вы можете продлить его командой /bill!",
    "inline_btns": [
        {
            "text": "▶️ Start",
            "callback_data": "start"
        },
        {
            "text": "⏹ Stop",
            "callback_data": "stop"
        },
        {
            "text": "⏸ Restart",
            "callback_data": "restart"
        },
        {
            "text": "⏏️ Info",
            "callback_data": "info"
        }
    ],
    "not_have_host": "У вас нет хостинга, вы можете купить его в боте!",
    "support": "<b>🔎Техническая поддержка: </b>@dev_CodWiz",
    "host_not_paid": "Хостинг не оплачен, вы можете продлить его в боте!",
    "promo_code": "🔖Введите промокод:",
    "promo_code_invalid": "Промокод уже был активирован или не существует!",
    "promo_code_valid": "Промокод успешно активирован\n(просто нажмите проверить оплату)!",
    "promo_saved": "Промокод {} сохранен!",
}

# CPU period and quota equivalent 0.25
CONTAINER = {
    "cpu_period": 50000,
    "cpu_quota": 25000,
    "mem_limit": "350m",
    "image": "hikka:latest",
    "ip": "185.195.25.254"
}

PAY = {
    "token": "",
    "receiver": "",
    "price": 35,
    "time": "1 месяц",
    "currency": "RUB",
    "description": "Хостинг для Hikka юзербота от Re:Host",
    "success_url": "",
}
