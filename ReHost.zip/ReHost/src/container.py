import docker
from config import CONTAINER

client = docker.from_env()


def create(port, name):
    client.containers.run(
        CONTAINER['image'],
        cpu_period=CONTAINER['cpu_period'],
        cpu_quota=CONTAINER['cpu_quota'],
        mem_limit=CONTAINER['mem_limit'],
        name=name,
        ports={8080: port},
        detach=True,
        tty=True,
    )


def stop(name):
    client.containers.get(name).stop()


def start(name):
    client.containers.get(name).start()


def restart(name):
    client.containers.get(name).restart()