import re
import random
import string
import json
from db.models.db_session import global_init, create_session
from db.models.users import User
from db.models.promo import Promo
from datetime import datetime, timedelta
from yoomoney import Quickpay, Client
from config import PAY
import socket
from contextlib import closing
from src.container import create, start, stop, restart

client = Client(PAY["token"])

global_init("db/database.db")


def get_random_gif() -> str:
    with open("src/gifs/cats.txt", "r") as f:
        gifs = f.read().splitlines()
    return random.choice(gifs)


def _process(text: str) -> str:
    return text.replace("<", "&lt;").replace(">", "&gt;")


def get_full_name(user) -> str:
    if getattr(user, "first_name", False):
        return _process(f"{user.first_name} "
                + (user.last_name if getattr(user, "last_name", False) else ""))
    else:
        return _process(f"{user['first_name']} "
                + (user['last_name'] if getattr(user, "last_name", False) else ""))


def get_link(user) -> str:
    if getattr(user, "username", False):
        return (
            f"tg://user?id={user.id}"
            if user.username
            else (
                f"tg://resolve?domain={user.username}"
                if getattr(user, "username", None)
                else ""
            )
        )
    else:
        return (
            f"tg://user?id={user['id']}"
            if user['username']
            else (
                f"tg://resolve?domain={user['username']}"
                if getattr(user, "username", None)
                else ""
            )
        )


def convert_time(t: str) -> int:
    try:
        if not str(t)[:-1].isdigit():
            return 0
        if "d" in str(t):
            t = int(t[:-1]) * 60 * 60 * 24
        if "h" in str(t):
            t = int(t[:-1]) * 60 * 60
        if "m" in str(t):
            t = int(t[:-1]) * 60
        if "s" in str(t):
            t = int(t[:-1])
        t = int(re.sub(r"[^0-9]", "", str(t)))
    except ValueError:
        return 0
    return t


def _get_user(user_id: int) -> User:
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    return user


def create_user(user_id: int) -> User:
    if _get_user(user_id):
        return

    session = create_session()
    user = User(id=user_id, data='{}', pay_token="")
    session.add(user)
    session.commit()
    session.close()
    return user


def get_user_data(user_id: int) -> dict:
    user = _get_user(user_id)
    if user:
        return {
            "id": user.id,
            "data": user.data,
            "pay_token": user.pay_token,
            "promo": user.promo
        }
    else:
        return {}


def edit_user_data(user_id: int, data: dict) -> None:
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return
    user.data = json.dumps(data)
    session.commit()
    session.close()


def edit_user_pay_token(user_id: int, pay_token: str) -> None:
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return
    user.pay_token = pay_token
    session.commit()
    session.close()


def check_hosts() -> None:
    # get all users
    session = create_session()
    users = session.query(User).all()
    result = []
    for user in users:
        data = json.loads(user.data)
        if data:
            if data:
                host_time = datetime.strptime(data["hosts"]["date"], "%d/%m/%Y %H:%M:%S")
                if host_time < datetime.now():
                    data["hosts"]["status"] = "stopped"
                    stop_host(user.id)
                    user.data = json.dumps(data)
                    result.append(user.id)

    session.commit()
    return result


def buy_host(user_id: int):
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    port = get_port()
    if user:
        data = json.loads(user.data)
        if data != {}:
            host_time = datetime.strptime(data["hosts"]["date"], "%d/%m/%Y %H:%M:%S")
            host_time = host_time + timedelta(days=30)
            data["hosts"]["date"] = host_time.strftime("%d/%m/%Y %H:%M:%S")
            data["hosts"]["status"] = "active"
        else:
            data["hosts"] = {
                "date": (datetime.now() + timedelta(days=30)).strftime("%d/%m/%Y %H:%M:%S"),
                "count": 1,
                "port": port,
                "status": "active"
            }
            name = user_id
            create(port, name)

        user.data = json.dumps(data)
        session.commit()
        session.close()
        return port


def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


def quick_pay(user_id: int):
    label = id_generator(8)
    quickpay = Quickpay(
        receiver=PAY['receiver'],
        quickpay_form="shop",
        targets=PAY['description'],
        paymentType="SB",
        sum=PAY['price'],
        label=label
    )

    edit_user_pay_token(user_id, label)
    return quickpay.base_url


def check_pay(user_id: int, is_owner: bool) -> bool:
   # label = get_user_data(user_id)["pay_token"]
   # history = client.operation_history(label=label)
   # for operation in history.operations:
    #    if operation.status == "success":
     #       edit_user_pay_token(user_id, '')
    #        return True

    if is_owner:
        edit_user_pay_token(user_id, '')
        return True
    
    if _get_user(user_id).promo:
        set_used_promo(user_id)
        return True
    return False


def check_port(port):
    host = '185.195.25.254'
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        if sock.connect_ex((host, port)) == 0:
            return True
        else:
            return False


def get_port():
    port = 1000
    while check_port(port):
        port += 1
    return port


def check_host(user_id: int) -> bool:
    data = get_user_data(user_id)
    data = json.loads(data["data"])
    if data:
        return data["hosts"]["count"]
    return False


def start_host(user_id: int) -> bool:
    user = _get_user(user_id)
    data = json.loads(user.data)
    if data["hosts"]["status"] == "stopped":
        return False

    start(str(user_id))
    return True


def stop_host(user_id: int) -> None:
    user = _get_user(user_id)
    data = json.loads(user.data)
    if data["hosts"]["status"] == "stopped":
        return False

    stop(str(user_id))
    return True


def restart_host(user_id: int) -> bool:
    user = _get_user(user_id)
    data = json.loads(user.data)
    if data["hosts"]["status"] == "stopped":
        return False

    restart(str(user_id))
    return True

def save_promo(promo: str) -> bool:
    session = create_session()
    promo = Promo(
        text=promo,
        status=1
    )
    session.add(promo)
    session.commit()
    session.close()
    return True

def use_promo(promo: str, user_id: int) -> bool:
    session = create_session()
    promo = session.query(Promo).filter(Promo.text == promo).first()
    if promo:
        promo.status = 0
        session.commit()
        session.close()
        give_promo(user_id)
        return True
    return False

def give_promo(user_id: int) -> bool:
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    if user:
        user.promo = 1
        session.commit()
        session.close()
        return True
    return False

def set_used_promo(user_id: int) -> bool:
    session = create_session()
    user = session.query(User).filter(User.id == user_id).first()
    if user:
        user.promo = 0
        session.commit()
        session.close()
        return True
    return False
