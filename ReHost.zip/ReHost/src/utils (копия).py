from yoomoney import Quickpay, Client
from config import PAY

client = Client(PAY["token"])

def quick_pay(user_id: int):
    label = id_generator(8)
    quickpay = Quickpay(
        receiver=PAY['receiver'],
        quickpay_form="shop",
        targets=PAY['description'],
        paymentType="SB",
        sum=PAY['price'],
        label=label
    )

    edit_user_pay_token(user_id, label)
    return quickpay.base_url


def check_pay(user_id: int, is_owner: bool) -> bool:
    label = get_user_data(user_id)["pay_token"]
    history = client.operation_history(label=label)
    for operation in history.operations:
        if operation.status == "success":
            edit_user_pay_token(user_id, '')
            return True

    #if is_owner:
    #    edit_user_pay_token(user_id, '')
    #    return True
    
    if _get_user(user_id).promo:
        set_used_promo(user_id)
        return True
    return False
