import asyncio

from aiogram import Bot, Dispatcher, types
from config import BOT

from datetime import datetime
import threading as th

from handlers import *
from src.utils import check_hosts

BOT_TOKEN = BOT["token"]


async def main():
    bot = Bot(token=BOT_TOKEN, parse_mode=BOT["parse_mode"])
    try:
        disp = Dispatcher()
        disp.message.register(start_handler, commands={"start"})
        disp.message.register(bill_handler, commands={"bill"})
        disp.message.register(promo_handler, commands={"promo"})
        disp.message.register(text_handler)

        disp.callback_query.register(callback_handler)

        disp.inline_query.register(inline_handler)

        await disp.start_polling(bot)
    except Exception as e:
        print(e)
    finally:
        print("Bot closing...")
        #await bot.close()
        print("Bot closed!")


def timer():
    print('Current cheking time: ', datetime.now().strftime("%H:%M:%S"))
    print('Stopped hosts: ', check_hosts())
    th.Timer(3600.0, timer).start()


if __name__ == "__main__":
    print("Bot and timer started!")
    timer()
    asyncio.run(main())
