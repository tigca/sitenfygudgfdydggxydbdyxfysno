from aiogram import types
from src.utils import check_pay, buy_host, start_host, stop_host, restart_host, get_user_data

import json

from config import STRING, BOT, CONTAINER


async def callback_handler(callback: types.CallbackQuery):
    host_btns = ["start", "stop", "restart", "info"]
    host = callback.from_user.id
    if callback.data in host_btns:
        d = json.loads(get_user_data(host)['data'])
        if not d:
            return await callback.answer(
                STRING["not_have_host"],
            )
        if d["hosts"]["status"] != "active":
            return await callback.answer(
                STRING["host_not_paid"],
            )

        if callback.data == "start":
            if start_host(host):
                await callback.answer("Хост запущен")
            else:
                await callback.answer(STRING["host_not_paid"])
        elif callback.data == "stop":
            if stop_host(host):
                await callback.answer("Хост остановлен")
            else:
                await callback.answer(STRING["host_not_paid"])
        elif callback.data == "restart":
            if restart_host(host):
                await callback.answer("Хост перезапущен")
            else:
                await callback.answer(STRING["host_not_paid"])
        elif callback.data == "info":
            await callback.answer(f"Дата окончания: {d['hosts']['date']}")

    if not get_user_data(callback.from_user.id)['pay_token']:
        return await callback.answer(
            STRING["already_have_host"],
        )
    pay = check_pay(callback.from_user.id, callback.from_user.username in BOT["owners"])
    if pay:
        await callback.message.answer(
            STRING["payed"],
        )
        port = buy_host(callback.from_user.id)
        await callback.message.answer(
            STRING["host_created"].format(f"{CONTAINER['ip']}{port}"),
        )
    else:
        await callback.answer(
            STRING["not_payed"],
        )

