# inline mode start, stop and restart buttons

from aiogram import types
from aiogram.types import InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardMarkup, InlineKeyboardButton

from src.utils import check_host, get_user_data

from config import STRING


async def inline_handler(query: types.InlineQuery):
    host = check_host(query.from_user.id)
    
    if not host:
        return

    if not get_user_data(query.from_user.id):
        return

    results = []

    btns = STRING["inline_btns"]

    for btn in btns:
        results.append(
            InlineQueryResultArticle(
                id=btn["callback_data"],
                title=btn["text"],
                input_message_content=InputTextMessageContent(
                    message_text=f"{btn['text']} host"
                ),
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text=btn["text"],
                                callback_data=btn["callback_data"]
                            )
                        ]
                    ]
                )
            )
        )

    # Важно указать is_personal=True!
    await query.answer(results, is_personal=True)
