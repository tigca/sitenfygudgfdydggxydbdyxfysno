from aiogram import types
from aiogram.utils.keyboard import InlineKeyboardBuilder
from src.utils import quick_pay, get_user_data

from config import STRING, PAY


async def bill_handler(event: types.Message):
    if event.chat.id == event.from_user.id:
        if get_user_data(event.from_user.id)['data'] == '{}':
            return await event.answer(
                STRING["not_have_host"],
            )

        pay = quick_pay(event.from_user.id)
        inline = InlineKeyboardBuilder()

        url = types.InlineKeyboardButton(
            text="Оплатить",
            url=pay
        )
        check = types.InlineKeyboardButton(
            text="Проверить оплату",
            callback_data="check_bill"
        )
        inline.add(*[url, check])

        await event.answer(
            STRING["bill"].format(PAY["price"], PAY["time"]),
            reply_markup=inline.as_markup(),
        )
