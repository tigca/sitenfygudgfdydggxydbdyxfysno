from aiogram import types
from aiogram.utils.keyboard import InlineKeyboardBuilder
from src.utils import quick_pay, get_user_data, use_promo

from config import STRING, PAY


async def text_handler(event: types.Message):
    if event.chat.id == event.from_user.id:
        if event.text == STRING["keyboard"]["support"]:
            return await event.answer(STRING["support"])

        if get_user_data(event.from_user.id)['data'] != '{}':
            return await event.answer(
                STRING["already_have_host"],
            )
        if event.text == STRING["keyboard"]["buy"]:
            pay = quick_pay(event.from_user.id)
            inline = InlineKeyboardBuilder()

            url = types.InlineKeyboardButton(
                text="Оплатить",
                url=pay
            )
            check = types.InlineKeyboardButton(
                text="Проверить оплату",
                callback_data="check_pay"
            )
            inline.add(*[url, check])

            await event.answer(
                STRING["buy"].format(PAY["price"], PAY["time"]),
                reply_markup=inline.as_markup(),
            )
        else:
            args = event.text
            if len(args.split(" ")) == 1:
                if use_promo(args, event.from_user.id):
                    return await event.answer(
                        STRING["promo_code_valid"],
                    )
                else:
                    return await event.answer(
                        STRING["promo_code_invalid"],
                    )

            await event.answer(
                STRING["unknown_command"],
            )
