from handlers.start import start_handler
from handlers.reply import text_handler
from handlers.callback import callback_handler
from handlers.inline import inline_handler
from handlers.bill import bill_handler
from handlers.promo import promo_handler