from aiogram import types
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from src.utils import get_full_name

from config import STRING
from src.utils import create_user


async def start_handler(event: types.Message):
    if event.chat.id == event.from_user.id:
        create_user(event.from_user.id)

        inline = InlineKeyboardBuilder()

        invite = types.InlineKeyboardButton(
            text="📣 Re:Host Channel",
            url="t.me/ссылку"
        )
        url = types.InlineKeyboardButton(
            text="🛡 Пользовательское соглашение",
            url=STRING["post"]
        )
        inline.add(*[invite, url])

        await event.answer(
            STRING["start"].format(get_full_name(event.from_user)),
            reply_markup=inline.as_markup(),
        )

        reply = ReplyKeyboardBuilder()

        reply.add(*[
            types.KeyboardButton(text=STRING["keyboard"]["buy"]),
            types.KeyboardButton(text=STRING["keyboard"]["support"]),
        ])

        await event.answer(
            STRING["keyboard_opened"],
            reply_markup=reply.as_markup(resize_keyboard=True),
        )
