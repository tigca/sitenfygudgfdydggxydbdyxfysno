from aiogram import types

from config import STRING, BOT

from src.utils import save_promo


async def promo_handler(event: types.Message):
    if event.chat.id == event.from_user.id:
        if event.from_user.username in BOT["owners"]:
            args = event.text.split(" ")
            promo = args[1]

            save_promo(promo)

            await event.answer(
                STRING["promo_saved"].format(promo),
            )
